#define PJMEDIA_AUDIO_DEV_HAS_ALSA		1
#undef PJMEDIA_AUDIO_DEV_HAS_PORTAUDIO
#define PJMEDIA_AUDIO_DEV_HAS_PORTAUDIO		0
#include <pj/config_site_sample.h>

//xia mian 4 ge  liuchang  dan shuohua mei shengyin
#define PJMEDIA_RESAMPLE_NONE   1
#define PJMEDIA_HAS_SPEEX_AEC   0
#define PJMEDIA_HAS_VIDEO   0
#define PJMEDIA_CONF_USE_SWITCH_BOARD 1

//#define PJ_HAS_FLOATING_POINT 0
//#define PJSIP_SAFE_MODULE 0
//#define PJSIP_UNESCAPE_IN_PLACE 1
//#define PJ_HASH_USE_OWN_TOLOWER 1